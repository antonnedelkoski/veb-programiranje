package mk.ukim.finki.wp.lab.web;

public class StudentEnrollmentSummary {
}
