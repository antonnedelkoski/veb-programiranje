package mk.ukim.finki.wp.lab.web;

import javax.servlet.annotation.WebServlet;

@WebServlet(name = "addStudent",urlPatterns = "/AddStudent")
public class ListStudentServlet {
}
