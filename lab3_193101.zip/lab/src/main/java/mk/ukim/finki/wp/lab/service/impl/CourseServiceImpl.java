package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import mk.ukim.finki.wp.lab.model.enumerations.Type;
import mk.ukim.finki.wp.lab.model.exceptions.TeacherNotFoundException;
import mk.ukim.finki.wp.lab.repository.jpa.CourseRepo;
import mk.ukim.finki.wp.lab.repository.jpa.StudentRepo;
import mk.ukim.finki.wp.lab.repository.jpa.TeacherRepo;
import mk.ukim.finki.wp.lab.service.CourseService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepo courseRepository;
    private final StudentRepo studentRepository;
    private final TeacherRepo teacherRepository;

    public CourseServiceImpl(CourseRepo courseRepository, StudentRepo studentRepository, TeacherRepo teacherRepository) {
        this.courseRepository = courseRepository;
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
    }

    @Override
    public List<Course> listAll() {
        return courseRepository.findAllCourses();
    }

    @Override
    public List<Student> listStudentsByCourse(Long courseId) {
        return courseRepository.findAllStudentsByCourse(courseId);
    }

    @Override
    public Course addStudentInCourse(String username, Long courseId) {
        Student student = studentRepository.findAllStudents().stream()
                .filter(i->i.getUsername().equals(username))
                .findFirst()
                .orElse(null);

        Course course = courseRepository.findById(courseId).orElse(null);

        courseRepository.addStudentToCourse(student, course);

        return course;
    }

    @Override
    public Optional<Course> save(String name, String description, List<Student> students, Long teacherId) {
        return Optional.empty();
    }

    @Override
    public Optional<Course> save(String name, String description, List<Student> students, Long teacherId, Type type) {
        Teacher teacher = this.teacherRepository.findById(teacherId)
                .orElseThrow(() -> new TeacherNotFoundException(teacherId));


        return Optional.of(this.courseRepository.save(new Course(name,description,students,teacher,type)));
    }

    @Override
    public void deleteById(Long id) {
        this.courseRepository.deleteById(id);
    }

    @Override
    public Optional<Course> findById(Long id) {
        return this.courseRepository.findById(id);
    }
}
