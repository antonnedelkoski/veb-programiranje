package mk.ukim.finki.wp.lab.model.enumerations;

public enum Type {
    WINTER ,
    SUMMER,
    MANDATORY,
    ELECTIVE
}
