package mk.ukim.finki.wp.lab.repository.impl;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import mk.ukim.finki.wp.lab.model.enumerations.Type;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CourseRepository {

    List<Course> courses;


    public CourseRepository(){
        courses = new ArrayList<>();

        List<Student> students = new ArrayList<>();
        List<Teacher> teachers = new ArrayList<>();

        students.add(new Student("student1", "pass1", "name1", "sur1"));
        students.add(new Student("student2", "pass2", "name2", "sur2"));
        students.add(new Student("student3", "pass3", "name3", "sur3"));
        students.add(new Student("student4", "pass4", "name4", "sur4"));
        students.add(new Student("student5", "pass5", "name5", "sur5"));


        /*Teacher teacher1 = new Teacher("Nike","NY NY");
        teachers.add(teacher1);
        Teacher teacher2 = new Teacher("Adidas","NY NY");
        teachers.add(teacher2);
        Teacher teacher3 = new Teacher("Puma","NY NY");
        teachers.add(teacher3);
        */

        /*courses.add(new Course( "Веб програмирање", "descCourse1", new ArrayList<>(
                Arrays.asList(students.get(0), students.get(1))),teacher1));
        courses.add(new Course("nameCourse2", "descCourse2", new ArrayList<>(
                Arrays.asList(students.get(1), students.get(2))),teacher2));
        courses.add(new Course("nameCourse3", "descCourse3", new ArrayList<>(
                Arrays.asList(students.get(2), students.get(3))),teacher3));
        courses.add(new Course( "nameCourse4", "descCourse4", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4))),teacher1));
        courses.add(new Course( "nameCourse5", "descCourse5", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4))),teacher2));

*/
    }


    public List<Course> findAllCourses() {

        return DataHolder.courses;
    }


    public Optional<Course> findById(Long id){
        return DataHolder.courses
                .stream()
                .filter(i -> i.getCourseId().equals(id))
                .findFirst();
    }

    public  List<Student> findAllStudentsByCourse(Long courseId){

        return findById(courseId).get().getStudents();
    }

    public Course addStudentToCourse(Student student, Course course){
        List<Student> studentsList = course.getStudents();
        studentsList.add(student);
        course.setStudents(studentsList);
        return course;
    }

    public Optional<Course> save(String name, String description , List<Student> students, Teacher teacher, Type type){

        DataHolder.courses.removeIf(i -> i.getName().equals(name));
        Course course = new Course(name,description,students,teacher,type);
        DataHolder.courses.add(course);
        return Optional.of(course);

    }


    public void deleteById(Long id){
        DataHolder.courses.removeIf(i ->i.getCourseId().equals(id));
    }
}
