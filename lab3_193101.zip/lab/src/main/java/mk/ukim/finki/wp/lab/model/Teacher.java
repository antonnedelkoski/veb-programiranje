package mk.ukim.finki.wp.lab.model;

import lombok.Data;
import mk.ukim.finki.wp.lab.converting.TeacherNameSurname;
import mk.ukim.finki.wp.lab.converting.TeacherNameSurnameConverter;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Entity
public class Teacher {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Convert(converter = TeacherNameSurnameConverter.class)
    private TeacherNameSurname teacherNameSurname;
    private LocalDate dateOfEmployment;

    public Teacher(TeacherNameSurname teacherNameSurname) {
        this.teacherNameSurname = teacherNameSurname;
        this.dateOfEmployment = LocalDate.from(LocalDateTime.now());
    }

    public Teacher() {

    }
}
