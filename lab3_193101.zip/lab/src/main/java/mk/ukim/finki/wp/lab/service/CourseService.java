package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.enumerations.Type;

import java.util.List;
import java.util.Optional;


public interface CourseService {

    List<Course> listAll();

    List<Student> listStudentsByCourse(Long courseId);

    Course addStudentInCourse(String username, Long courseId);

    Optional<Course> save(String name, String description, List<Student> students, Long teacherId);

    Optional<Course> save(String name, String description, List<Student> students, Long teacherId, Type type);

    void deleteById(Long id);

    Optional<Course> findById(Long id);

}
