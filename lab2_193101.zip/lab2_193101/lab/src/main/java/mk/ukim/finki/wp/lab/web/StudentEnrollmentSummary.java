package mk.ukim.finki.wp.lab.web;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.service.CourseService;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "StudentEnrollment", urlPatterns = "/StudentEnrollmentSummary")
public class StudentEnrollmentSummary extends HttpServlet {

    private final SpringTemplateEngine templateEngine;
    private final CourseService courseService;

    public StudentEnrollmentSummary(SpringTemplateEngine templateEngine, CourseService courseService) {
        this.templateEngine = templateEngine;
        this.courseService = courseService;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        WebContext webContext = new WebContext(req, resp, this.getServletContext());
        long courseId = (long) req.getSession().getAttribute("courseId");
        List<Student> students = courseService.listStudentsByCourse(courseId);
        Course course = courseService.listAll().stream()
                .filter(x -> x.getCourseId().equals(courseId))
                .findFirst()
                .orElse(null);
        webContext.setVariable("students", students);
        webContext.setVariable("course", course.getName());

        this.templateEngine.process("studentsInCourse.html", webContext, resp.getWriter());
    }

}
