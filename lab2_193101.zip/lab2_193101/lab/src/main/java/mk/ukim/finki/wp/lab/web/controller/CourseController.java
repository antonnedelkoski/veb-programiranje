package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import mk.ukim.finki.wp.lab.service.CourseService;
import mk.ukim.finki.wp.lab.service.StudentService;
import mk.ukim.finki.wp.lab.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/courses")
public class CourseController {

    private final CourseService courseService;
    private final StudentService studentService;
    private final TeacherService teacherService;

    public CourseController(CourseService courseService, StudentService studentService, TeacherService teacherService) {
        this.courseService = courseService;
        this.studentService = studentService;
        this.teacherService = teacherService;
    }

    @GetMapping
    public String getCoursesPage(@RequestParam(required = false) String error, Model model) {
        List<Course> courses = this.courseService.listAll();
        model.addAttribute("courses", courses);

        return "listCourses";
    }

    @PostMapping("/add")
    public String saveCourse(@RequestParam String name,
                             @RequestParam String description,
                             @RequestParam("studentUsername") List<String> studentUsernames,
                             @RequestParam Long teacher) {
        List<Student> studentList = new ArrayList<>();

        for (String studentUsername : studentUsernames) {
            studentList.add(studentService.findByUsername(studentUsername));
        }
        this.courseService.save(name, description, studentList, teacher);

        return "redirect:/courses";
    }

    @PostMapping("/delete/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteById(id);

        return "redirect:/courses";
    }

    @GetMapping("/edit-form/{id}")
    public String getEditCoursePage(@PathVariable Long id, Model model) {

        if (courseService.findById(id).isPresent()) {
            Course course = courseService.findById(id).get();
            List<Student> students = studentService.listAll();
            List<Teacher> teachers = teacherService.findAll();
            model.addAttribute("course", course);
            model.addAttribute("students", students);
            model.addAttribute("teachers", teachers);

            return "edit-course";
        }

        return "redirect:/courses?error=CourseNotFound";
    }

    @GetMapping("/add-form")
    public String getAddCoursePage(Model model) {
        List<Student> students = studentService.listAll();
        List<Teacher> teachers = teacherService.findAll();
        model.addAttribute("students", students);
        model.addAttribute("teachers", teachers);

        return "add-course";
    }

}