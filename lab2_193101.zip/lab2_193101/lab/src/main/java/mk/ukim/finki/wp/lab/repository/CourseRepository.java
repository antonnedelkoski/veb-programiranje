package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepository {

    public List<Course> findAllCourses() {
        return DataHolder.courses;
    }

    public Optional<Course> findById(Long id) {
        return DataHolder.courses
                .stream()
                .filter(i -> i.getCourseId().equals(id))
                .findFirst();
    }

    public List<Student> findAllStudentsByCourse(Long courseId) {
        return findById(courseId).get().getStudents();
    }

    public Course addStudentToCourse(Student student, Course course) {
        List<Student> studentsList = course.getStudents();
        studentsList.add(student);
        course.setStudents(studentsList);

        return course;
    }

    public Optional<Course> save(String name, String description, List<Student> students, Teacher teacher) {
        DataHolder.courses.removeIf(i -> i.getName().equals(name));
        Course course = new Course(name, description, students, teacher);
        DataHolder.courses.add(course);

        return Optional.of(course);

    }

    public void deleteById(Long id) {
        DataHolder.courses.removeIf(i -> i.getCourseId().equals(id));
    }

}
