package mk.ukim.finki.wp.lab.bootstrap;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Component
public class DataHolder {

    public static List<Student> students = new ArrayList<>();
    public static List<Course> courses = new ArrayList<>();
    public static List<Teacher> teachers = new ArrayList<>();

    @PostConstruct
    public void init() {
        students.add(new Student("student1", "salamavaljda", "Димитар ", "Џајкоски"));
        students.add(new Student("student2", "mala_prespa", "Столе ", "Мартин"));
        students.add(new Student("student3", "evropa", "Тале ", "Европски"));
        students.add(new Student("student4", "pass4", "Крсте ", "Крстески"));
        students.add(new Student("student5", "pass5", "Петре ", "Петрески"));


        Teacher teacher1 = new Teacher("Игор ", "Мишковски");
        teachers.add(teacher1);
        Teacher teacher2 = new Teacher("Сашо ", "Граматиков");
        teachers.add(teacher2);
        Teacher teacher3 = new Teacher("Ристе ", "Стојанов");
        teachers.add(teacher3);
        Teacher teacher4 = new Teacher("Иван ", "Чорбев");
        teachers.add(teacher4);
        Teacher teacher5 = new Teacher("Слободан ", "Калајџиски");
        teachers.add(teacher5);


        courses.add(new Course("Веб програмирање", "descCourse1", new ArrayList<>(
                Arrays.asList(students.get(0), students.get(1))), teacher1));
        courses.add(new Course("Оперативни системи", "descCourse2", new ArrayList<>(
                Arrays.asList(students.get(1), students.get(2))), teacher2));
        courses.add(new Course("Компјутерски мрежи", "descCourse3", new ArrayList<>(
                Arrays.asList(students.get(2), students.get(3))), teacher3));
        courses.add(new Course("Интегрирани системи", "descCourse4", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4))), teacher1));
        courses.add(new Course("Структурно програмирање", "descCourse5", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4))), teacher2));
    }

}
