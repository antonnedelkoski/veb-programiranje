package mk.ukim.finki.wp.lab.repository.impl;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class StudentRepository {
    List<Student> students;

    public StudentRepository(){
        students = new ArrayList<>();

        students.add(new Student("student1", "pass1", "name1", "sur1"));
        students.add(new Student("student2", "pass2", "name2", "sur2"));
        students.add(new Student("student3", "pass3", "name3", "sur3"));
        students.add(new Student("student4", "pass4", "name4", "sur4"));
        students.add(new Student("student5", "pass5", "name5", "sur5"));

    }

    public List<Student> findAllStudents() {
        return DataHolder.students;
    }


    public List<Student> findAllByNameOrSurname(String text) {
        return DataHolder.students.stream().filter(r->r.getName().contains(text)
                || r.getSurname().contains(text)).collect(Collectors.toList());
    }


    public Student save(Student c) {
        if (c==null || c.getName()==null || c.getName().isEmpty()){
            return null;
        }
        DataHolder.students.removeIf(r -> r.getName().equals(c.getName()));//dokolku postoi kategorijata da se prebrise
        DataHolder.students.add(c);//dodavanje na novata kategorija
        return c;
    }

    public Student findByUsername(String username) {
        return DataHolder.students.stream().filter(s -> s.getUsername().equals(username)).findFirst().get();
    }
}

