package mk.ukim.finki.wp.lab.repository.impl;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.Teacher;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class TeacherRepository {
    /*private final List<Teacher> teachers;

    public TeacherRepository(){
        teachers = new ArrayList<>();

        Teacher teacher1 = new Teacher("Nike","NY NY");
        teachers.add(teacher1);
        Teacher teacher2 = new Teacher("Adidas","NY NY");
        teachers.add(teacher2);
        Teacher teacher3 = new Teacher("Puma","NY NY");
        teachers.add(teacher3);
    }*/

    public List<Teacher> findAll(){
        return DataHolder.teachers;
    }

    public Optional<Teacher> findById(Long id){
        return DataHolder.teachers.stream().filter(i -> i.getId().equals(id)).findFirst();
    }
}
