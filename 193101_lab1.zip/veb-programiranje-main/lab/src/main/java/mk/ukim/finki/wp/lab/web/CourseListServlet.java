package mk.ukim.finki.wp.lab.web;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.service.CourseService;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CourseList",urlPatterns = "/listCourses")
public class CourseListServlet extends HttpServlet {

    private final CourseService courseService;
    private final SpringTemplateEngine templateEngine;

    public CourseListServlet(CourseService courseService, SpringTemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
        this.courseService = courseService;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Course> courses = courseService.listAll();
        WebContext webContext = new WebContext(req, resp, this.getServletContext());
        webContext.setVariable("courses", courses);

        this.templateEngine.process("listCourses.html", webContext, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long courseId = Long.valueOf(req.getParameter("courseId"));
        req.getSession().setAttribute("courseId",courseId);
        resp.sendRedirect("/AddStudent");
    }
}
