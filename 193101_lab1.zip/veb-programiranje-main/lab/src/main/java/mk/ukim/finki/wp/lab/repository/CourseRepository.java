package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepository {
    private  List<Course> courseList;

    public CourseRepository() {
        courseList = new ArrayList<>();

        List<Student> students = new ArrayList<>();

        students = new ArrayList<>();
        students.add(new Student("astrohelmet","tons","Jas","Sebesi"));
        students.add(new Student("legolas","bow","Legolas","Longbow"));
        students.add(new Student("geralt","yen","Geralt","of Rivia"));
        students.add(new Student("luke","skyw","Luke","Skywalker"));
        students.add(new Student("arthas","lichking","Arthas","Menethil"));

        courseList.add(new Course(1L, "Computer Science", "descCourse1", new ArrayList<>(
                Arrays.asList(students.get(0), students.get(1)))));
        courseList.add(new Course(2L, "Science", "descCourse2", new ArrayList<>(
                Arrays.asList(students.get(1), students.get(2)))));
        courseList.add(new Course(3L, "Computer", "descCourse3", new ArrayList<>(
                Arrays.asList(students.get(2), students.get(3)))));
        courseList.add(new Course(4L, "Software Engineering", "descCourse4", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4)))));
        courseList.add(new Course(5L, "Engineering", "descCourse5", new ArrayList<>(
                Arrays.asList(students.get(3), students.get(4)))));

    }

    public List<Course> findAllCourses(){
        return this.courseList;
    }

    public Optional<Course> findById(Long courseId){
        return courseList.stream()
                .filter(i->i.getCourseId().equals(courseId))
                .findFirst();
    }

    public  List<Student> findAllStudentsByCourse(Long courseId){
        return findById(courseId).get().getStudents();
    }

    public Course addStudentToCourse(Student student, Course course){
        List<Student> studentsList = course.getStudents();
        studentsList.add(student);
        course.setStudents(studentsList);
        return course;
    }


}
