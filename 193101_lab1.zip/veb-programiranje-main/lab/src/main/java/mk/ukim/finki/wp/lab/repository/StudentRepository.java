package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class StudentRepository {

    private final List<Student> studentList;

    public StudentRepository() {
        studentList = new ArrayList<>();
        studentList.add(new Student("astrohelmet","tons","Jas","Sebesi"));
        studentList.add(new Student("legolas","bow","Legolas","Longbow"));
        studentList.add(new Student("geralt","yen","Geralt","of Rivia"));
        studentList.add(new Student("luke","skyw","Luke","Skywalker"));
        studentList.add(new Student("arthas","lichking","Arthas","Menethil"));
    }

    public List<Student> findAllStudents(){
        return this.studentList;
    }

    public List<Student> findAllByNameOrSurname(String text){
        return studentList.stream()
                .filter(i -> i.getName().contains(text) || i.getSurname().contains(text))
                .collect(Collectors.toList());
    }

    public void addStudent(Student s){
        this.studentList.add(s);
    }

    public void removeStudent(Student s){
        this.studentList.remove(s);
    }
}